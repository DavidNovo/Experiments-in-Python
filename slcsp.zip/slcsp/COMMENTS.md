# How to Run The Solution
This scripts assumes that a version of Python 3.7 or higher is installed on the local system. 
This ensures that dictionaries are ordered.

The script requires the plans.csv, slcsp.csv and zips.csv files to be in the same directory as the script.

To execute the script run the following command in this directory '➜python sliver_plan_check.py'
